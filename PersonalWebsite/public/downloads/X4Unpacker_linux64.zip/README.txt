# X4 Unpacker for X4 8.0.3

It unpacks the compressed X4 data so it can be used by modders to understand the game. It works on more platforms (Win, Linux, MacOS) then the original X4 Catalog Tool.

## How to use

Simply put all unpacker files in the same folder where you can find the .cat files usually its .../X4: Foundations/ then execute the unpacker it automatically unpacks all .cat files in the main game and from all extensions. It creates an unpacked data folder where you can find all uncompressed data.
