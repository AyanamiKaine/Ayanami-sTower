// VESSEL_ANALYSIS (AUTOMATED VERSION)
// This version has all interactive dialogs removed.
// It assumes:
// 1. An image is already open.
// 2. It will automatically CROP the image to the hard-coded dimensions.
// 3. It will automatically save to the hard-coded directory.
// 4. It will automatically run "Vascular Density Metrics".

requires("1.47g");
base = getTitle();
// HARD-CODED directory from your macro.
// Note: Make sure this folder exists!
directory = "/home/ayanami/Pictures/";

setBatchMode(true);

// --- NEW AUTOMATED CROP ---
// We are re-introducing the cropping logic,
// but automating it with the dimensions you provided.

// ** PLEASE EDIT THESE if your crop needs to start somewhere other than (0, 0) **
// makeRectangle(x_start, y_start, width, height)
// You gave width=856 (x) and height=853 (y).
// FIX: Removed 'int' declarations. This is IJM, not Java.
crop_x_start = 272;
crop_y_start = 0;
crop_width = 856;
crop_height = 853;

print("Applying automated crop at: " + crop_x_start + "," + crop_y_start + " w:" + crop_width + " h:" + crop_height);
makeRectangle(crop_x_start, crop_y_start, crop_width, crop_height);
run("Crop");
run("Select None");

// Save the cropped image (like the original plugin)
// The window title will change to "Cropped-" + base
saveAs("Tiff", directory + "Cropped-" + base);
base = getTitle(); // base is now "Cropped-..."

// --- End of new crop logic ---


/********************************************** * Create a binary image of vasculature    *
**********************************************/ 

// Duplicate the *active* image (which is now the cropped one)
run("Duplicate...", "title=Binary-" + base);
rename("Binary-" + base);
binary = getTitle();
	
// Preserve green channel; discard red and blue channels
run("Split Channels");
selectWindow(binary + " (blue)");
close();
selectWindow(binary + " (red)");
close();
selectWindow(binary + " (green)");
	
// Equalize histogram; apply Laplacian of Gaussian filter & auto-threshold
run("Enhance Contrast...", "saturated=0.4 equalize");
run("Mexican Hat Filter", "radius=10");
run("Auto Threshold", "method=Shanbhag");
		
// Fill in holes 
run("Remove Outliers...", "radius=5 threshold=50 which=Dark");
		
// Remove background noise
for (i = 0; i < 2; i++)
	run("Remove Outliers...", "radius=3 threshold=0 which=Bright");
// FIX: Corrected typo 'i_0' to 'i < 10'
for (i = 0; i < 10; i++) 
	run("Despeckle");

saveAs("Tiff", directory + binary);
close(base); // Close the "Cropped-" base image, leaving the binary open
setBatchMode(false); // Temporarily exit batch mode for next step
	
/************************************* * Perform vessel measurements    *
*************************************/ 

// PROBLEM 3 REMOVED:
// We skip the Dialog.create() and hard-code the choice.
// Note: The plugin's code uses "Vascular Density Metrics" (with an "s")
choice = "Vascular Density Metrics";

setBatchMode(true);

// PROBLEM 4 REMOVED:
// We remove the do-while(repeat) loop. We just run the choice once.

if (choice == "Diameter Measurements") {
    // This code block is preserved in case you want to change
    // the 'choice' variable to "Diameter Measurements" later.
	run("Duplicate...", "title=[" + binary + "]");
	rename("Duplicate-" + binary);
	duplicate = getTitle();
	
	run("Geometry to Distance Map", "threshold=1");
	// FIX: Corrected typo 'getTItle' to 'getTitle'
	processed = getTitle();
	
	selectWindow(duplicate);
	setOption("BlackBackground", true);
	run("Skeletonize");
	
	run("RGB Color");
	run("8-bit Color", "number=2");
	
	imageCalculator("Multiply create 32-bit", duplicate, processed);
	run("Fire");
	intermediate = getTitle();
	
	imageCalculator("Add create 32-bit", intermediate, intermediate);
	
	rename("EDM-" + base);
	result = getTitle();
	saveAs("Tiff", directory + result);
	
	close(duplicate); 
	close(processed);
	close(intermediate);
	selectWindow(result);
	setBatchMode(false);
	run("Diameter Measurements");
}

else if (choice == "Vascular Density Metrics") {
    // This is the part that will run
	selectWindow(binary);
	saveAs("Tiff", directory + "VD" + binary);


    // --- END FIX ---
	makeRectangle(0, 0, 857, 860);
	run("Vascular Density"); // This will no longer pause
	
	// The original plugin re-opened the binary image, which seems odd.
	// We'll keep it for now.
	open(binary);
	
	// --- Your macro's logic, added here for completeness ---
	// The "Results" window should be active after run("Vascular Density");
	
	// !! IMPORTANT !!
	// The "Vascular Density" plugin probably creates a results table
	// named "Results". But another plugin might be running
	// (Vascular Length Density?). I will trust your macro logic here.
	
	// This Table.rename might fail if "Results" isn't the active table.
	// Let's assume "Vascular Density" makes "Results"
	Table.rename("Results", "Vascular Density Measurements");
	saveAs("Results", directory + "Vascular Density Measurements.csv");
	
	// Your macro tried to rename "Results" twice.
	// This suggests two different result tables are created.
	// If "Vascular Density" creates *two* tables, this logic is tricky.
	// For now, I will assume it creates one, and you also
	// want to save a "Length" measurement, which might come
	// from another plugin not shown here.
	
	// I will just save the one table.
}
else {
	print("No operation was selected.");
}

// Select and close the binary image
selectImage(binary);
close();

setBatchMode(false);
print("Automated analysis complete.");

