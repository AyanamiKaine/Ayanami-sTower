// VASCULAR DENSITY

/************************************ 
*     Select region of interest     *
************************************/ 
image = getTitle();
directory = getDirectory("image");
repeat = false;

do {
	do { 
		// Prompt user to select region of interest (default to polygon selection tool)
		setTool("polygon");
		beep();
		waitForUser("Choose ROI", "Select your region of interest, then click OK.");
	} while(selectionType() == -1); 

	setOption("Changes", true);
	save(directory + image);

	/************************************************************************ 
	*     Calculate vascular densities (ratio of white pixels to total)     *
	************************************************************************/ 

	setBatchMode(true);

	if(isOpen("Vascular Density Measurements")) {
		selectWindow("Vascular Density Measurements"); 
		IJ.renameResults("Results");
	}
	
	run("Set Measurements...", "area_fraction redirect=None decimal=3");
	run("Measure");
	density = getResult("%Area")/100;
	selectWindow("Results");
	IJ.renameResults("Vascular Density Measurements"); 

	if(isOpen("Vascular Length Density Measurements")) {
		selectWindow("Vascular Length Density Measurements"); 
		IJ.renameResults("Results");
	}

	setOption("BlackBackground", true);
	run("Skeletonize");
	run("Measure");
	lengthDensity = getResult("%Area")/100;
	selectWindow("Results");
	IJ.renameResults("Vascular Length Density Measurements");

	setOption("Changes", false);
	close();
	open(directory + image);
	setBatchMode(false);
	
	// Ask user whether to repeat density measurements
	repeat = getBoolean("Would you like to calculate the vascular density of another region?");
	
	
} while(repeat);