// DIAMETER_MEASUREMENTS

result = getTitle();
directory = getDirectory("image");
setBatchMode(false);

// Get image dimensions in pixels and mm
Dialog.create("Enter dimensions");
Dialog.addNumber("Distance in mm", 0);
Dialog.addNumber("Distance in pixels", 0);
Dialog.show();

// Calculate pixel/mm ratio & set scale based on input
mmDist = Dialog.getNumber();
pixelDist = Dialog.getNumber();
conversionFactor = mmDist/pixelDist;
run("Set Scale...", "distance=" + pixelDist + " known=" + mmDist + " pixel=1 unit=mm");

// Calculate average diameter of vessel ROI
do {
	selectWindow(result);
	
	do { 
		// Prompt user to select region (default to rectangle selection tool)
		setTool(0);
		beep();
		waitForUser("Select ROI", "Select a vessel segment, then click OK.");
	} while(selectionType() != 0); 
	
	setBatchMode(true); 
	getSelectionCoordinates(x, y);
	startX = x[0];
	startY = y[0];
	endX = x[2];
	endY = y[2];

	var dist=0, count=0, total=0, average=0;

	// Loop through pixels in ROI
	for (v = startY; v <= endY; v++) {
		for (h = startX; h <= endX; h++) {
			dist = getPixel(h,v); 	
			
			// Account for non-black pixels only
			if (dist != 0) {
				count++; 
				total += dist; 
			}
		}
	}

	// Print average diameter 
 	average = (total/count) * conversionFactor;
	setSelectionName(average + "mm");
	
	// Overlay label for selected ROI
	run("Add Selection...");
	run("Labels...", "color=white font=10 show use bold");
	
	setBatchMode(false);

	// Ask user to select another region of interest
	cont = getBoolean("Would you like to calculate the average diameter of another region?");
	
} while(cont)

run("Save");
flatten = getBoolean("Would you like to save a copy of the flattened image?");
if (flatten) {
	setBatchMode(true);
	run("Flatten");
	name = getTitle();
	save(directory + name);
	close(name);
	setBatchMode(false);
}