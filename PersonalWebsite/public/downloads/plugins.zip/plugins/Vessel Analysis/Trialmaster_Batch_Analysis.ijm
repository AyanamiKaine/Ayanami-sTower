// TRIALMASTER BATCH ANALYSIS
// Unified batch analysis for flat and nested OCTA datasets.
// Detects eye/layer metadata from folder names and filenames and writes
// one wide results CSV plus one QC manifest CSV.

requires("1.47g");

// ========================================
// KONFIGURATION
// ========================================

inputDir = "";
outputDir = "";
PLUGIN_BUILD = "2026-03-18-svc-debug";
PLUGIN_COPY_ID = "root";

OCTA_SIZE_MM = 2.9;
PHANSALKAR_RADIUS = 6;

CROP_LEFT = 275;
CROP_RIGHT = 275;
CROP_TOP = 0;
CROP_BOTTOM = 110;

TOLERANCE_START = 2;
TOLERANCE_MAX = 10;
TOLERANCE_STEP = 2;
MAGIC_WAND_MODE = "4-connected";

FAZ_MIN_AREA_MM2 = 0.10;
FAZ_MAX_AREA_MM2 = 0.80;
FAZ_MIN_CIRCULARITY = 0.60;
FAZ_MAXIMA_PROMINENCE = 10;
FAZ_SEARCH_FRACTION = 0.60;
FAZ_CANDIDATE_COUNT = 3;

DO_PERFUSION_DENSITY = true;
DO_VESSEL_DENSITY = true;
DO_FAZ = true;
DO_CC_FD = true;
SAVE_INTERMEDIATE_IMAGES = true;
SAVE_FAZ_OVERLAY = true;

DIR_ORIGINAL = "";
DIR_CROPPED = "";
DIR_8BIT = "";
DIR_BINARY = "";
DIR_FAZ_OVERLAY = "";
DIR_RESULTS = "";

MANIFEST_TABLE = "Input_Manifest";
VASCULAR_RESULTS_TABLE = "Vascular_Results";
CC_RESULTS_TABLE = "CC_Results";

PAIR_SEPARATOR = "|||";
LINE_SEPARATOR = "\n";

// ========================================
// HAUPTPROGRAMM
// ========================================

function main() {
	inputDir = getDirectory("Wählen Sie den Eingabeordner mit OCTA-Bildern");
	if (inputDir == "") exit("Abgebrochen.");
	outputDir = getDirectory("Wählen Sie den Ausgabeordner für Ergebnisse");
	if (outputDir == "") exit("Abgebrochen.");
	inputDir = normalizePath(inputDir);
	outputDir = normalizePath(outputDir);

	Dialog.create("Trialmaster Batch-Analyse");
	Dialog.addMessage("Der Plugin scannt Dateinamen und Unterordner,\n" +
		"um Layer und Auge automatisch zu erkennen.");
	Dialog.addCheckbox("Perfusionsdichte (PD) für DCP/ICP/SVP/SVC/DVC", DO_PERFUSION_DENSITY);
	Dialog.addCheckbox("Vessel Density (VD) für DCP/ICP/SVP/SVC/DVC", DO_VESSEL_DENSITY);
	Dialog.addCheckbox("FAZ manuell für DCP/ICP/SVP/SVC/DVC", DO_FAZ);
	Dialog.addCheckbox("Choriocapillaris Flow Deficit (CC FD)", DO_CC_FD);
	Dialog.addNumber("OCTA Bildgröße (mm):", OCTA_SIZE_MM);
	Dialog.addCheckbox("Zwischenschritte speichern", SAVE_INTERMEDIATE_IMAGES);
	Dialog.addCheckbox("FAZ Overlay speichern", SAVE_FAZ_OVERLAY);
	Dialog.show();

	DO_PERFUSION_DENSITY = Dialog.getCheckbox();
	DO_VESSEL_DENSITY = Dialog.getCheckbox();
	DO_FAZ = Dialog.getCheckbox();
	DO_CC_FD = Dialog.getCheckbox();
	OCTA_SIZE_MM = Dialog.getNumber();
	SAVE_INTERMEDIATE_IMAGES = Dialog.getCheckbox();
	SAVE_FAZ_OVERLAY = Dialog.getCheckbox();

	DIR_ORIGINAL = outputDir + "01_original/";
	DIR_CROPPED = outputDir + "02_cropped/";
	DIR_8BIT = outputDir + "03_8bit/";
	DIR_BINARY = outputDir + "04_binary_images/";
	DIR_FAZ_OVERLAY = outputDir + "05_FAZ_overlay/";
	DIR_RESULTS = outputDir + "05_results/";

	File.makeDirectory(DIR_ORIGINAL);
	File.makeDirectory(DIR_CROPPED);
	File.makeDirectory(DIR_8BIT);
	File.makeDirectory(DIR_BINARY);
	File.makeDirectory(DIR_FAZ_OVERLAY);
	File.makeDirectory(DIR_RESULTS);
	discoveredText = collectImagesIterative(inputDir);
	discoveredPairs = split(discoveredText, LINE_SEPARATOR);
	discoveredCount = countDiscoveredPairs(discoveredPairs);
	print("Discovery count after scan: " + discoveredCount);

	if (discoveredCount == 0) {
		showMessage("Fehler", "Keine Bilddateien im gewählten Ordner gefunden.");
		return;
	}

	initializeTables();

	print("\n=== TRIALMASTER BATCH ANALYSIS ===");
	print("Build: " + PLUGIN_BUILD + " (" + PLUGIN_COPY_ID + ")");
	print("Input: " + inputDir);
	print("Output: " + outputDir);
	print("Starte rekursiven Scan...");
	print("File.separator: [" + File.separator + "]");
	print("Gefundene Bilder: " + discoveredCount);

	setBatchMode(true);

	processedCount = 0;
	skippedCount = 0;
	reviewCount = 0;

	runIndex = 0;
	for (i = 0; i < discoveredPairs.length; i++) {
		pair = discoveredPairs[i];
		if (pair == "") continue;
		separatorIndex = indexOf(pair, PAIR_SEPARATOR);
		if (separatorIndex < 0) continue;

		fullPath = substring(pair, 0, separatorIndex);
		relativePath = substring(pair, separatorIndex + lengthOf(PAIR_SEPARATOR), lengthOf(pair));

		showProgress(runIndex, discoveredCount);
		print("\n(" + (runIndex + 1) + "/" + discoveredCount + ") " + relativePath);

		metadata = parseImageMetadata(relativePath);
		baseFilename = metadata[0];
		sampleId = metadata[1];
		eyeSide = metadata[2];
		layer = metadata[3];
		expectedAnalyses = metadata[4];
		parseStatus = metadata[5];
		parseDetail = metadata[6];
		outputKey = makeOutputKey(relativePath);

		addManifestRow(relativePath, baseFilename, sampleId, eyeSide, layer, expectedAnalyses, parseStatus, parseDetail, outputKey);

		if (parseStatus == "Skipped") {
			print("  -> Übersprungen: " + parseDetail);
			skippedCount++;
			continue;
		}

		if (parseStatus == "Needs_Review") {
			reviewCount++;
		}

		resultTable = VASCULAR_RESULTS_TABLE;
		if (layer == "CC") resultTable = CC_RESULTS_TABLE;
		resultRow = initializeResultRow(relativePath, baseFilename, sampleId, eyeSide, layer, expectedAnalyses, parseStatus, parseDetail, outputKey, resultTable);
		processImage(fullPath, relativePath, outputKey, layer, resultRow, resultTable);
		processedCount++;
		runIndex++;
		run("Collect Garbage");
	}

	setBatchMode(false);

	saveResults();

	showMessage("Fertig!",
		"Batch-Analyse abgeschlossen!\n\n" +
		"Gefundene Bilder: " + discoveredCount + "\n" +
		"Verarbeitet: " + processedCount + "\n" +
		"Metadaten übersprungen: " + skippedCount + "\n" +
		"Mit Prüfhinweis: " + reviewCount + "\n\n" +
		"Ergebnisse gespeichert in:\n" + DIR_RESULTS);
}

// ========================================
// INPUT DISCOVERY
// ========================================

function collectImagesIterative(rootDir) {
	queueText = rootDir + PAIR_SEPARATOR;
	foundText = "";

	while (queueText != "") {
		newlineIndex = indexOf(queueText, LINE_SEPARATOR);
		if (newlineIndex < 0) {
			currentItem = queueText;
			queueText = "";
		} else {
			currentItem = substring(queueText, 0, newlineIndex);
			queueText = substring(queueText, newlineIndex + lengthOf(LINE_SEPARATOR), lengthOf(queueText));
		}

		if (currentItem == "") continue;

		separatorIndex = indexOf(currentItem, PAIR_SEPARATOR);
		if (separatorIndex < 0) continue;

		currentDir = substring(currentItem, 0, separatorIndex);
		relativePrefix = substring(currentItem, separatorIndex + lengthOf(PAIR_SEPARATOR), lengthOf(currentItem));

		fileList = getFileList(currentDir);
		print("Scanne Ordner: " + currentDir + " (" + fileList.length + " Einträge)");

		for (i = 0; i < fileList.length; i++) {
			entry = fileList[i];
			if (isDirectoryEntry(entry)) {
				print("  [DIR] " + entry);
				queueText = appendDiscoveryText(queueText, currentDir + entry + PAIR_SEPARATOR + relativePrefix + entry);
			} else if (isImageFile(entry)) {
				print("  [IMG] " + entry);
				foundText = appendDiscoveryText(foundText, currentDir + entry + PAIR_SEPARATOR + relativePrefix + entry);
			} else {
				print("  [SKIP] " + entry);
			}
		}
	}

	return foundText;
}

function countDiscoveredPairs(discoveredPairs) {
	count = 0;
	for (i = 0; i < discoveredPairs.length; i++) {
		if (discoveredPairs[i] != "") count++;
	}
	return count;
}

// ========================================
// METADATA ERKENNUNG
// ========================================

function parseImageMetadata(relativePath) {
	baseFilename = File.getNameWithoutExtension(relativePath);
	baseUpper = "_" + toUpperCase(baseFilename) + "_";
	sampleId = extractSampleId(baseFilename);
	normalized = normalizeForTokens(relativePath);
	normalizedWrapped = "_" + normalized + "_";
	tokens = split(normalized, "_");

	eyeSide = "Unknown";
	layer = "Unknown";

	for (i = 0; i < tokens.length; i++) {
		token = tokens[i];
		layerCandidate = "";
		if (token == "") continue;

		if (eyeSide == "Unknown" && (token == "OD" || token == "OS")) {
			eyeSide = token;
		}

		if (layer == "Unknown") {
			layerCandidate = mapLayerToken(token);
			if (layerCandidate != "") layer = layerCandidate;
		}
	}

	if (eyeSide == "Unknown") {
		if (indexOf(normalizedWrapped, "_OD_") >= 0) eyeSide = "OD";
		else if (indexOf(normalizedWrapped, "_OS_") >= 0) eyeSide = "OS";
	}
	if (layer == "Unknown") {
		layer = detectLayerFromWrappedText(normalizedWrapped);
	}
	if (eyeSide == "Unknown") {
		if (indexOf(baseUpper, "_OD_") >= 0) eyeSide = "OD";
		else if (indexOf(baseUpper, "_OS_") >= 0) eyeSide = "OS";
	}
	if (layer == "Unknown") {
		layer = detectLayerFromWrappedText(baseUpper);
	}
	if (layer == "Unknown") {
		layer = detectLayerFromFilenameSuffix(baseFilename);
	}

	expectedAnalyses = determineExpectedAnalyses(layer);
	parseStatus = "OK";
	parseDetail = "";

	if (layer == "Unknown") {
		parseStatus = "Skipped";
		parseDetail = "Layer konnte aus Dateiname oder Ordnerstruktur nicht erkannt werden.";
	} else if (eyeSide == "Unknown") {
		parseStatus = "Needs_Review";
		parseDetail = "Auge konnte nicht sicher erkannt werden.";
	}

	return newArray(baseFilename, sampleId, eyeSide, layer, expectedAnalyses, parseStatus, parseDetail);
}

function extractSampleId(baseFilename) {
	normalized = normalizeForTokens(baseFilename);
	tokens = split(normalized, "_");
	sampleId = "";
	foundMarker = false;

	for (i = 0; i < tokens.length; i++) {
		token = tokens[i];
		if (token == "") continue;
		if (isMetadataToken(token)) {
			foundMarker = true;
			break;
		}
		if (sampleId == "") sampleId = token;
		else sampleId = sampleId + "_" + token;
	}

	if (sampleId == "") {
		return baseFilename;
	}

	if (!foundMarker) {
		return baseFilename;
	}

	return sampleId;
}

function isMetadataToken(token) {
	if (token == "OD" || token == "OS") return 1;
	layerToken = mapLayerToken(token);
	if (layerToken == "") return 0;
	return 1;
}

function mapLayerToken(token) {
	if (token == "DCP") return "DCP";
	if (token == "ICP") return "ICP";
	if (token == "SCP" || token == "SVP") return "SVP";
	if (token == "SVC") return "SVC";
	if (token == "DVC") return "DVC";
	if (token == "CCFD" || token == "CC" || token == "CHORIO" || token == "CHO" || token == "CHORIOCAPILLARIS") return "CC";
	return "";
}

function detectLayerFromWrappedText(wrappedText) {
	if (indexOf(wrappedText, "_DCP_") >= 0) return "DCP";
	if (indexOf(wrappedText, "_ICP_") >= 0) return "ICP";
	if (indexOf(wrappedText, "_SVC_") >= 0) return "SVC";
	if (indexOf(wrappedText, "_DVC_") >= 0) return "DVC";
	if (indexOf(wrappedText, "_SVP_") >= 0 || indexOf(wrappedText, "_SCP_") >= 0) return "SVP";
	if (indexOf(wrappedText, "_CCFD_") >= 0 || indexOf(wrappedText, "_CHORIOCAPILLARIS_") >= 0 || indexOf(wrappedText, "_CHORIO_") >= 0 || indexOf(wrappedText, "_CHO_") >= 0 || indexOf(wrappedText, "_CC_") >= 0) return "CC";
	return "Unknown";
}

function detectLayerFromFilenameSuffix(baseFilename) {
	upperBase = toUpperCase(baseFilename);
	if (endsWith(upperBase, "_DCP")) return "DCP";
	if (endsWith(upperBase, "_ICP")) return "ICP";
	if (endsWith(upperBase, "_SVC")) return "SVC";
	if (endsWith(upperBase, "_DVC")) return "DVC";
	if (endsWith(upperBase, "_SVP") || endsWith(upperBase, "_SCP")) return "SVP";
	if (endsWith(upperBase, "_CCFD") || endsWith(upperBase, "_CHORIOCAPILLARIS") || endsWith(upperBase, "_CHORIO") || endsWith(upperBase, "_CHO") || endsWith(upperBase, "_CC")) return "CC";
	return "Unknown";
}

function determineExpectedAnalyses(layer) {
	if (layer == "CC") return "CC_FD";
	if (layer == "DCP" || layer == "ICP" || layer == "SVP" || layer == "SVC" || layer == "DVC") return "PD|VD|FAZ";
	return "Unknown";
}

function normalizeForTokens(text) {
	normalized = toUpperCase(text);
	normalized = replace(normalized, File.separator, "_");
	normalized = replace(normalized, "/", "_");
	normalized = replace(normalized, "-", "_");
	normalized = replace(normalized, " ", "_");
	normalized = replace(normalized, ".", "_");
	normalized = replace(normalized, "(", "_");
	normalized = replace(normalized, ")", "_");
	normalized = replace(normalized, "[", "_");
	normalized = replace(normalized, "]", "_");
	while (indexOf(normalized, "__") >= 0) {
		normalized = replace(normalized, "__", "_");
	}
	return normalized;
}

function makeOutputKey(relativePath) {
	key = normalizeForTokens(removeImageExtension(relativePath));
	if (startsWith(key, "_")) key = substring(key, 1, lengthOf(key));
	if (endsWith(key, "_")) key = substring(key, 0, lengthOf(key) - 1);
	return key;
}

function removeImageExtension(path) {
	lowerPath = toLowerCase(path);
	if (endsWith(lowerPath, ".tiff")) return substring(path, 0, lengthOf(path) - 5);
	if (endsWith(lowerPath, ".jpeg")) return substring(path, 0, lengthOf(path) - 5);
	if (endsWith(lowerPath, ".tif")) return substring(path, 0, lengthOf(path) - 4);
	if (endsWith(lowerPath, ".jpg")) return substring(path, 0, lengthOf(path) - 4);
	if (endsWith(lowerPath, ".png")) return substring(path, 0, lengthOf(path) - 4);
	if (endsWith(lowerPath, ".bmp")) return substring(path, 0, lengthOf(path) - 4);
	return path;
}

// ========================================
// VERARBEITUNG
// ========================================

function processImage(fullPath, relativePath, outputKey, layer, rowIndex, resultTable) {
	closeAllImages();
	run("Clear Results");

	open(fullPath);
	originalTitle = getTitle();

	if (SAVE_INTERMEDIATE_IMAGES) {
		saveAs("Tiff", DIR_ORIGINAL + outputKey + "_01_original.tif");
		originalTitle = getTitle();
	}

	width = getWidth();
	height = getHeight();
	cropWidth = width - CROP_LEFT - CROP_RIGHT;
	cropHeight = height - CROP_TOP - CROP_BOTTOM;

	if (cropWidth <= 0 || cropHeight <= 0) {
		appendWarning(rowIndex, resultTable, "Crop nicht möglich: Bild kleiner als erwartete Randabstände.");
		Table.set("Process_Status", rowIndex, "Failed_Crop", resultTable);
		Table.update(resultTable);
		closeAllImages();
		return;
	}

	makeRectangle(CROP_LEFT, CROP_TOP, cropWidth, cropHeight);
	run("Crop");
	run("Select None");

	if (SAVE_INTERMEDIATE_IMAGES) {
		saveAs("Tiff", DIR_CROPPED + outputKey + "_02_cropped.tif");
	}

	setCurrentScale();

	if (bitDepth() != 8) {
		run("8-bit");
	}

	if (SAVE_INTERMEDIATE_IMAGES) {
		saveAs("Tiff", DIR_8BIT + outputKey + "_03_8bit.tif");
	}

	workingImageTitle = getTitle();
	totalArea = measureCurrentTotalArea();
	Table.set("Total_Area_mm2", rowIndex, totalArea, resultTable);

	analysisRun = 0;

	if (layer == "CC") {
		if (DO_CC_FD) {
			selectWindow(workingImageTitle);
			analyzeChoriocapillarisFD(workingImageTitle, outputKey, rowIndex, resultTable);
			analysisRun++;
		} else {
			appendWarning(rowIndex, resultTable, "CC erkannt, aber CC FD ist im Dialog deaktiviert.");
		}
	} else if (layer == "DCP" || layer == "ICP" || layer == "SVP" || layer == "SVC" || layer == "DVC") {
		if (DO_FAZ) {
			selectWindow(workingImageTitle);
			analyzeFAZManual(workingImageTitle, outputKey, rowIndex, resultTable);
			analysisRun++;
		}
		if (DO_PERFUSION_DENSITY) {
			selectWindow(workingImageTitle);
			analyzePerfusionDensity(workingImageTitle, outputKey, rowIndex, resultTable);
			analysisRun++;
		}
		if (DO_VESSEL_DENSITY) {
			selectWindow(workingImageTitle);
			analyzeVesselDensity(workingImageTitle, outputKey, rowIndex, resultTable);
			analysisRun++;
		}
		if (analysisRun == 0) {
			appendWarning(rowIndex, resultTable, "Gefäß-Layer erkannt, aber alle Analysen sind deaktiviert.");
		}
	}

	if (analysisRun > 0) {
		currentWarnings = normalizeWarningValue(Table.get("Warnings", rowIndex, resultTable));
		if (currentWarnings == "") Table.set("Process_Status", rowIndex, "Processed", resultTable);
		else Table.set("Process_Status", rowIndex, "Processed_With_Warnings", resultTable);
	} else {
		Table.set("Process_Status", rowIndex, "Skipped_Settings", resultTable);
	}

	Table.update(resultTable);
	closeAllImages();
	run("Clear Results");
}

function analyzePerfusionDensity(sourceImageTitle, outputKey, rowIndex, resultTable) {
	selectWindow(sourceImageTitle);
	run("Duplicate...", "title=PD_working");

	setAutoThreshold("Otsu dark");
	setOption("BlackBackground", true);
	run("Convert to Mask");

	if (SAVE_INTERMEDIATE_IMAGES) {
		saveAs("Tiff", DIR_BINARY + outputKey + "_04_PD_binary.tif");
	}

	run("Select All");
	run("Set Measurements...", "area area_fraction redirect=None decimal=4");
	run("Measure");

	areaFraction = getResult("%Area", nResults - 1);
	totalArea = getResult("Area", nResults - 1);
	perfusionDensity = areaFraction / 100;

	Table.set("Total_Area_mm2", rowIndex, totalArea, resultTable);
	Table.set("Perfusion_Density_%", rowIndex, areaFraction, resultTable);
	Table.set("Perfusion_Density_Fraction", rowIndex, perfusionDensity, resultTable);
	Table.update(resultTable);

	run("Clear Results");
	close();
}

function analyzeVesselDensity(sourceImageTitle, outputKey, rowIndex, resultTable) {
	selectWindow(sourceImageTitle);
	run("Duplicate...", "title=VD_working");

	setAutoThreshold("Otsu dark");
	setOption("BlackBackground", true);
	run("Convert to Mask");
	run("Skeletonize");

	if (SAVE_INTERMEDIATE_IMAGES) {
		saveAs("Tiff", DIR_BINARY + outputKey + "_04_VD_skeleton.tif");
	}

	run("Select All");
	run("Set Measurements...", "area area_fraction redirect=None decimal=4");
	run("Measure");

	areaFraction = getResult("%Area", nResults - 1);
	totalArea = getResult("Area", nResults - 1);
	vesselDensity = areaFraction / 100;

	Table.set("Total_Area_mm2", rowIndex, totalArea, resultTable);
	Table.set("Vessel_Density_%", rowIndex, areaFraction, resultTable);
	Table.set("Vessel_Density_Fraction", rowIndex, vesselDensity, resultTable);
	Table.update(resultTable);

	run("Clear Results");
	close();
}

function analyzeChoriocapillarisFD(sourceImageTitle, outputKey, rowIndex, resultTable) {
	selectWindow(sourceImageTitle);
	run("Duplicate...", "title=CC_FD_working");

	run("Auto Local Threshold", "method=Phansalkar radius=" + PHANSALKAR_RADIUS + " parameter_1=0 parameter_2=0 white");
	run("Invert");

	if (SAVE_INTERMEDIATE_IMAGES) {
		saveAs("Tiff", DIR_BINARY + outputKey + "_04_CC_FD_binary.tif");
	}

	run("Select All");
	run("Set Measurements...", "area area_fraction redirect=None decimal=4");
	run("Measure");

	fdAreaFraction = getResult("%Area", nResults - 1);
	totalArea = getResult("Area", nResults - 1);
	fdDensity = fdAreaFraction / 100;

	run("Clear Results");
	run("Set Measurements...", "area mean redirect=None decimal=6");
	run("Analyze Particles...", "size=0-Infinity show=Nothing display clear");

	fdCount = nResults;
	fdAvgSize = 0;
	fdTotalArea = 0;

	if (fdCount > 0) {
		for (j = 0; j < fdCount; j++) {
			fdTotalArea += getResult("Area", j);
		}
		fdAvgSize = fdTotalArea / fdCount;
	}

	Table.set("Total_Area_mm2", rowIndex, totalArea, resultTable);
	Table.set("Flow_Deficit_%", rowIndex, fdAreaFraction, resultTable);
	Table.set("Flow_Deficit_Fraction", rowIndex, fdDensity, resultTable);
	Table.set("FD_Count", rowIndex, fdCount, resultTable);
	Table.set("FD_Total_Area_mm2", rowIndex, fdTotalArea, resultTable);
	Table.set("FD_Avg_Size_mm2", rowIndex, fdAvgSize, resultTable);
	Table.update(resultTable);

	run("Clear Results");
	close();
}

function analyzeFAZManual(sourceImageTitle, outputKey, rowIndex, resultTable) {
	selectWindow(sourceImageTitle);
	roiManager("reset");
	setBatchMode(false);
	selectWindow(sourceImageTitle);
	run("Select None");
	setTool("polygon");
	waitForUser("FAZ manuell messen",
		"Bitte die FAZ im OCT-A Bild manuell einzeichnen.\n" +
		"Verwenden Sie das Polygon-Werkzeug und klicken Sie danach OK.\n\n" +
		"Gemessen werden: Area, Perimeter, Circularity.\n" +
		"Ohne Auswahl wird FAZ für dieses Bild übersprungen.");

	selectWindow(sourceImageTitle);
	if (selectionType() == -1) {
		appendWarning(rowIndex, resultTable, "FAZ nicht manuell markiert.");
		roiManager("reset");
		setBatchMode(true);
		return;
	}

	roiManager("Add");
	bestROI = roiManager("count") - 1;
	roiManager("Select", bestROI);
	run("Clear Results");
	run("Set Measurements...", "area perimeter shape redirect=None decimal=4");
	run("Measure");

	fazArea = getResult("Area", nResults - 1);
	fazPerimeter = getResult("Perim.", nResults - 1);
	fazCircularity = getResult("Circ.", nResults - 1);
	fazDiameter = 2 * sqrt(fazArea / PI);

	Table.set("FAZ_Area_mm2", rowIndex, fazArea, resultTable);
	Table.set("FAZ_Perimeter_mm", rowIndex, fazPerimeter, resultTable);
	Table.set("FAZ_Diameter_mm", rowIndex, fazDiameter, resultTable);
	Table.set("FAZ_Circularity", rowIndex, fazCircularity, resultTable);
	if (fazArea < 0.035 || fazArea > 0.9) {
		appendWarning(rowIndex, resultTable, "FAZ-Fläche außerhalb des erwarteten Bereichs (0.035-0.9 mm²).");
	}
	Table.update(resultTable);

	if (SAVE_FAZ_OVERLAY) {
		createFAZOverlay(sourceImageTitle, outputKey, bestROI);
	} else {
		roiManager("Select", bestROI);
		roiManager("Save", DIR_RESULTS + outputKey + "_FAZ.roi");
		roiManager("reset");
	}

	run("Clear Results");
	run("Select None");
	roiManager("reset");
	setBatchMode(true);
}

function createFAZOverlay(sourceImageTitle, outputKey, roiIndex) {
	selectWindow(sourceImageTitle);
	run("Duplicate...", "title=FAZ_overlay");
	run("RGB Color");
	roiManager("Select", roiIndex);
	setForegroundColor(255, 255, 0);
	run("Draw");
	saveAs("Tiff", DIR_FAZ_OVERLAY + outputKey + "_05_FAZ_overlay.tif");
	roiManager("Select", roiIndex);
	roiManager("Save", DIR_RESULTS + outputKey + "_FAZ.roi");
	close();
}

// ========================================
// TABELLEN UND OUTPUT
// ========================================

function initializeTables() {
	if (isOpen(MANIFEST_TABLE)) {
		selectWindow(MANIFEST_TABLE);
		run("Close");
	}
	if (isOpen(VASCULAR_RESULTS_TABLE)) {
		selectWindow(VASCULAR_RESULTS_TABLE);
		run("Close");
	}
	if (isOpen(CC_RESULTS_TABLE)) {
		selectWindow(CC_RESULTS_TABLE);
		run("Close");
	}
	Table.create(MANIFEST_TABLE);
	Table.create(VASCULAR_RESULTS_TABLE);
	Table.create(CC_RESULTS_TABLE);
}

function addManifestRow(relativePath, baseFilename, sampleId, eyeSide, layer, expectedAnalyses, parseStatus, parseDetail, outputKey) {
	rowIndex = Table.size(MANIFEST_TABLE);
	Table.set("Source_Relative_Path", rowIndex, relativePath, MANIFEST_TABLE);
	Table.set("Source_Filename", rowIndex, baseFilename, MANIFEST_TABLE);
	Table.set("Sample_ID", rowIndex, sampleId, MANIFEST_TABLE);
	Table.set("Eye", rowIndex, eyeSide, MANIFEST_TABLE);
	Table.set("Layer", rowIndex, layer, MANIFEST_TABLE);
	Table.set("Expected_Analyses", rowIndex, expectedAnalyses, MANIFEST_TABLE);
	Table.set("Parse_Status", rowIndex, parseStatus, MANIFEST_TABLE);
	Table.set("Parse_Detail", rowIndex, parseDetail, MANIFEST_TABLE);
	Table.set("Output_Key", rowIndex, outputKey, MANIFEST_TABLE);
	Table.update(MANIFEST_TABLE);
}

function initializeResultRow(relativePath, baseFilename, sampleId, eyeSide, layer, expectedAnalyses, parseStatus, parseDetail, outputKey, resultTable) {
	rowIndex = Table.size(resultTable);
	Table.set("Source_Relative_Path", rowIndex, relativePath, resultTable);
	Table.set("Source_Filename", rowIndex, baseFilename, resultTable);
	Table.set("Sample_ID", rowIndex, sampleId, resultTable);
	Table.set("Eye", rowIndex, eyeSide, resultTable);
	Table.set("Layer", rowIndex, layer, resultTable);
	Table.set("Expected_Analyses", rowIndex, expectedAnalyses, resultTable);
	Table.set("Parse_Status", rowIndex, parseStatus, resultTable);
	Table.set("Process_Status", rowIndex, "Pending", resultTable);
	Table.set("Output_Key", rowIndex, outputKey, resultTable);
	Table.set("Warnings", rowIndex, parseDetail, resultTable);
	if (resultTable == VASCULAR_RESULTS_TABLE) {
		Table.set("Total_Area_mm2", rowIndex, "", resultTable);
		Table.set("Perfusion_Density_%", rowIndex, "", resultTable);
		Table.set("Perfusion_Density_Fraction", rowIndex, "", resultTable);
		Table.set("Vessel_Density_%", rowIndex, "", resultTable);
		Table.set("Vessel_Density_Fraction", rowIndex, "", resultTable);
		Table.set("FAZ_Area_mm2", rowIndex, "", resultTable);
		Table.set("FAZ_Perimeter_mm", rowIndex, "", resultTable);
		Table.set("FAZ_Diameter_mm", rowIndex, "", resultTable);
		Table.set("FAZ_Circularity", rowIndex, "", resultTable);
	} else {
		Table.set("Total_Area_mm2", rowIndex, "", resultTable);
		Table.set("Flow_Deficit_%", rowIndex, "", resultTable);
		Table.set("Flow_Deficit_Fraction", rowIndex, "", resultTable);
		Table.set("FD_Count", rowIndex, "", resultTable);
		Table.set("FD_Total_Area_mm2", rowIndex, "", resultTable);
		Table.set("FD_Avg_Size_mm2", rowIndex, "", resultTable);
	}
	Table.update(resultTable);
	return rowIndex;
}

function appendWarning(rowIndex, resultTable, warningText) {
	currentWarnings = normalizeWarningValue(Table.get("Warnings", rowIndex, resultTable));
	if (currentWarnings == "") Table.set("Warnings", rowIndex, warningText, resultTable);
	else Table.set("Warnings", rowIndex, currentWarnings + " | " + warningText, resultTable);
	Table.update(resultTable);
}

function saveResults() {
	timestamp = getTimestamp();
	if (Table.size(VASCULAR_RESULTS_TABLE) > 0) {
		saveTableAsLocalizedCSV(VASCULAR_RESULTS_TABLE, DIR_RESULTS + "Vascular_Results_" + timestamp + ".csv", "vascular");
	}
	if (Table.size(CC_RESULTS_TABLE) > 0) {
		saveTableAsLocalizedCSV(CC_RESULTS_TABLE, DIR_RESULTS + "CC_Results_" + timestamp + ".csv", "cc");
	}
	print("\n✓ Ergebnisse gespeichert:");
	print("  - " + DIR_RESULTS + "Vascular_Results_" + timestamp + ".csv");
	print("  - " + DIR_RESULTS + "CC_Results_" + timestamp + ".csv");
}

// ========================================
// HILFSFUNKTIONEN
// ========================================

function isImageFile(name) {
	lowerName = toLowerCase(name);
	return endsWith(lowerName, ".tif") || endsWith(lowerName, ".tiff") ||
		endsWith(lowerName, ".jpg") || endsWith(lowerName, ".jpeg") ||
		endsWith(lowerName, ".png") || endsWith(lowerName, ".bmp");
}

function isDirectoryEntry(name) {
	return endsWith(name, "/") || endsWith(name, "\\") || endsWith(name, File.separator);
}

function appendDiscoveryText(existingText, newText) {
	if (newText == "") return existingText;
	if (existingText == "") return newText;
	return existingText + LINE_SEPARATOR + newText;
}

function normalizePath(path) {
	normalizedPath = replace(path, "\\", "/");
	if (!endsWith(normalizedPath, "/")) normalizedPath = normalizedPath + "/";
	return normalizedPath;
}

function normalizeWarningValue(value) {
	normalizedValue = value;
	if (normalizedValue == "null") normalizedValue = "";
	if (normalizedValue == "NaN") normalizedValue = "";
	if (normalizedValue == " ") normalizedValue = "";
	return normalizedValue;
}

function saveTableAsLocalizedCSV(tableName, filePath, tableType) {
	if (tableType == "vascular") {
		columns = newArray(
			"Source_Relative_Path", "Source_Filename", "Sample_ID", "Eye", "Layer",
			"Expected_Analyses", "Parse_Status", "Process_Status", "Output_Key",
			"Total_Area_mm2", "Perfusion_Density_%", "Perfusion_Density_Fraction",
			"Vessel_Density_%", "Vessel_Density_Fraction", "FAZ_Area_mm2",
			"FAZ_Perimeter_mm", "FAZ_Diameter_mm", "FAZ_Circularity", "Warnings"
		);
	} else {
		columns = newArray(
			"Source_Relative_Path", "Source_Filename", "Sample_ID", "Eye", "Layer",
			"Expected_Analyses", "Parse_Status", "Process_Status", "Output_Key",
			"Total_Area_mm2", "Flow_Deficit_%", "Flow_Deficit_Fraction",
			"FD_Count", "FD_Total_Area_mm2", "FD_Avg_Size_mm2", "Warnings"
		);
	}

	csvText = buildLocalizedCSVLine(columns);
	rowCount = Table.size(tableName);
	for (r = 0; r < rowCount; r++) {
		rowValues = newArray(columns.length);
		for (c = 0; c < columns.length; c++) {
			columnName = columns[c];
			cellValue = Table.getString(columnName, r, tableName);
			if (cellValue == "null") cellValue = "";
			if (isNumericColumn(columnName) && cellValue != "" && cellValue != "NaN") {
				cellValue = replace(cellValue, ".", ",");
			}
			rowValues[c] = cellValue;
		}
		csvText = csvText + "\r\n" + buildLocalizedCSVLine(rowValues);
	}

	File.saveString(csvText, filePath);
}

function buildLocalizedCSVLine(values) {
	line = "";
	for (i = 0; i < values.length; i++) {
		if (i > 0) line = line + ";";
		line = line + escapeCSVField(values[i]);
	}
	return line;
}

function escapeCSVField(value) {
	escaped = value;
	escaped = replace(escaped, "\"", "\"\"");
	if (indexOf(escaped, ";") >= 0 || indexOf(escaped, "\"") >= 0 || indexOf(escaped, "\n") >= 0 || indexOf(escaped, "\r") >= 0) {
		escaped = "\"" + escaped + "\"";
	}
	return escaped;
}

function isNumericColumn(columnName) {
	if (columnName == "Total_Area_mm2") return 1;
	if (columnName == "Perfusion_Density_%") return 1;
	if (columnName == "Perfusion_Density_Fraction") return 1;
	if (columnName == "Vessel_Density_%") return 1;
	if (columnName == "Vessel_Density_Fraction") return 1;
	if (columnName == "FAZ_Area_mm2") return 1;
	if (columnName == "FAZ_Perimeter_mm") return 1;
	if (columnName == "FAZ_Diameter_mm") return 1;
	if (columnName == "FAZ_Circularity") return 1;
	if (columnName == "Flow_Deficit_%") return 1;
	if (columnName == "Flow_Deficit_Fraction") return 1;
	if (columnName == "FD_Count") return 1;
	if (columnName == "FD_Total_Area_mm2") return 1;
	if (columnName == "FD_Avg_Size_mm2") return 1;
	return 0;
}

function setCurrentScale() {
	width = getWidth();
	run("Set Scale...", "distance=" + width + " known=" + OCTA_SIZE_MM + " unit=mm global");
}

function measureCurrentTotalArea() {
	run("Clear Results");
	run("Select All");
	run("Set Measurements...", "area redirect=None decimal=4");
	run("Measure");
	totalArea = getResult("Area", nResults - 1);
	run("Select None");
	run("Clear Results");
	return totalArea;
}

function closeAllImages() {
	titles = getList("image.titles");
	for (i = 0; i < titles.length; i++) {
		selectWindow(titles[i]);
		close();
	}
}

function getTimestamp() {
	getDateAndTime(year, month, dayOfWeek, dayOfMonth, hour, minute, second, msec);
	timestamp = "" + year;
	if (month < 9) timestamp = timestamp + "0";
	timestamp = timestamp + (month + 1);
	if (dayOfMonth < 10) timestamp = timestamp + "0";
	timestamp = timestamp + dayOfMonth + "_";
	if (hour < 10) timestamp = timestamp + "0";
	timestamp = timestamp + hour;
	if (minute < 10) timestamp = timestamp + "0";
	timestamp = timestamp + minute;
	if (second < 10) timestamp = timestamp + "0";
	timestamp = timestamp + second;
	return timestamp;
}

// ========================================
// PROGRAMMSTART
// ========================================

main();
