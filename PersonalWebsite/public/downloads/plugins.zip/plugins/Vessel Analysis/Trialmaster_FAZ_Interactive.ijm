// TRIALMASTER FAZ MESSUNG (AUTOMATISCH)
// Automatische Messung der Fovealen Avaskulären Zone (FAZ)
// Mit Magic Wand Tool (Tolerance=2, 4-connected)
// Gemäß Trialmaster-Anleitung

requires("1.47g");

// ========================================
// KONFIGURATION
// ========================================

OCTA_SIZE_MM = 2.9; // Standard OCTA Bildgröße in mm

// ADAPTIVE TOLERANZ-KONFIGURATION
TOLERANCE_START = 2;        // Starttoleranz (konservativ)
TOLERANCE_MAX = 10;         // Maximale Toleranz
TOLERANCE_STEP = 2;         // Schrittweite beim Erhöhen
MAGIC_WAND_MODE = "4-connected"; // 4-connected oder 8-connected

// FAZ QUALITÄTSKRITERIEN
FAZ_MIN_AREA_MM2 = 0.10;    // Minimum FAZ-Fläche (zu klein = Fehler)
FAZ_MAX_AREA_MM2 = 0.80;    // Maximum FAZ-Fläche (zu groß = Fehler)
FAZ_MIN_CIRCULARITY = 0.60; // Minimum Zirkularität (zu irregulär = Fehler)

// ========================================
// HAUPTPROGRAMM
// ========================================

function main() {
	// Prüfe ob ein Bild geöffnet ist
	if (nImages == 0) {
		showMessage("Fehler", "Bitte öffnen Sie zuerst ein OCTA-Bild.");
		return;
	}
	
	originalImage = getTitle();
	baseFilename = File.getNameWithoutExtension(originalImage);
	directory = getDirectory("image");
	
	// Frage Benutzer nach Ausgabeverzeichnis
	outputDir = getDirectory("Wählen Sie den Ausgabeordner");
	
	// Erstelle Ausgabeordner für FAZ
	File.makeDirectory(outputDir + "01_original" + File.separator);
	File.makeDirectory(outputDir + "02_cropped" + File.separator);
	File.makeDirectory(outputDir + "03_8bit" + File.separator);
	File.makeDirectory(outputDir + "04_FAZ_overlay" + File.separator);
	File.makeDirectory(outputDir + "05_results" + File.separator);
	
	// SCHRITT 1: Speichere Original
	selectWindow(originalImage);
	saveAs("Tiff", outputDir + "01_original" + File.separator + baseFilename + "_01_original.tif");
	originalImage = getTitle();
	
	// AUTOMATISCHES CROPPING
	// Schritt 1: 275px von links und rechts entfernen
	// Schritt 2: 110px von unten entfernen
	selectWindow(originalImage);
	widthOrig = getWidth();
	heightOrig = getHeight();
	
	// Berechne Crop-Parameter
	cropX = 275; // Von links
	cropY = 0; // Von oben (kein Crop oben)
	cropWidth = widthOrig - 550; // 275px links + 275px rechts entfernen
	cropHeight = heightOrig - 110; // 110px von unten entfernen
	
	makeRectangle(cropX, cropY, cropWidth, cropHeight);
	run("Crop");
	run("Select None");
	
	// SCHRITT 2: Speichere gecroptes Bild
	saveAs("Tiff", outputDir + "02_cropped" + File.separator + baseFilename + "_02_cropped.tif");
	originalImage = getTitle();
	
	print("FAZ-Analyse:");
	print("  Original: " + widthOrig + "px × " + heightOrig + "px");
	print("  Cropped: " + cropWidth + "px × " + cropHeight + "px (275px von links+rechts, 110px von unten)");
	
	// Set Scale
	setImageScale(originalImage);
	
	// Konvertiere zu 8-bit falls nötig
	if (bitDepth() != 8) {
		run("8-bit");
	}
	
	// SCHRITT 3: Speichere 8-bit Version
	saveAs("Tiff", outputDir + "03_8bit" + File.separator + baseFilename + "_03_8bit.tif");
	originalImage = getTitle();
	
	// Erstelle Ergebnis-Tabelle falls nicht vorhanden
	if (!isOpen("FAZ_Results")) {
		Table.create("FAZ_Results");
	}
	
	// Starte automatische FAZ-Erkennung
	measureFAZAutomatic(baseFilename, outputDir);
	
	// Speichere Ergebnisse
	timestamp = getTimestamp();
	Table.save(outputDir + "05_results" + File.separator + "FAZ_Results_" + timestamp + ".csv", "FAZ_Results");
	
	showMessage("Fertig!", "FAZ-Messung abgeschlossen!\n\nErgebnisse gespeichert in:\n" + outputDir);
}

// ========================================
// FAZ MESSUNG (AUTOMATISCH)
// ========================================

function measureFAZAutomatic(baseFilename, outputDir) {
	// Bildgröße ermitteln
	width = getWidth();
	height = getHeight();
	
	// Bildmitte berechnen (dort liegt normalerweise die FAZ)
	centerX = round(width / 2);
	centerY = round(height / 2);
	
	print("\n=== Automatische FAZ-Erkennung ===");
	print("  Bildgröße: " + width + "×" + height + " px");
	print("  Mitte: (" + centerX + ", " + centerY + ")");
	print("  Adaptive Toleranz: " + TOLERANCE_START + " bis " + TOLERANCE_MAX);
	print("  Modus: " + MAGIC_WAND_MODE);
	
	// Setze Magic Wand Tool Parameter
	setTool("wand");
	
	// ADAPTIVE TOLERANZ: Teste verschiedene Werte
	bestTolerance = -1;
	bestArea = 0;
	bestCircularity = 0;
	bestROI = -1;
	
	print("\n  → Teste adaptive Toleranz in Bildmitte...");
	
	// Teste verschiedene Toleranzen
	for (tolerance = TOLERANCE_START; tolerance <= TOLERANCE_MAX; tolerance += TOLERANCE_STEP) {
		// Versuche Magic Wand mit aktueller Toleranz
		doWand(centerX, centerY, tolerance, MAGIC_WAND_MODE);
		
		// Prüfe ob Selektion existiert
		if (selectionType() == -1) {
			print("    Tolerance=" + tolerance + ": Keine Selektion");
			continue;
		}
		
		// Messe aktuelle Selektion
		run("Set Measurements...", "area perimeter shape redirect=None decimal=4");
		run("Measure");
		
		testArea = getResult("Area", nResults-1);
		testPerimeter = getResult("Perim.", nResults-1);
		testCircularity = getResult("Circ.", nResults-1);
		
		// Prüfe Qualitätskriterien
		isValid = true;
		reason = "";
		
		if (testArea < FAZ_MIN_AREA_MM2) {
			isValid = false;
			reason = "zu klein";
		} else if (testArea > FAZ_MAX_AREA_MM2) {
			isValid = false;
			reason = "zu groß";
		} else if (testCircularity < FAZ_MIN_CIRCULARITY) {
			isValid = false;
			reason = "nicht kreisförmig";
		}
		
		// Speichere ROI falls gültig
		if (isValid) {
			roiManager("Add");
			currentROI = roiManager("count") - 1;
			
			// Ist diese Selektion besser als die bisherige?
			// Bevorzuge: höhere Zirkularität, dann größere Fläche
			isBetter = false;
			if (bestTolerance == -1) {
				isBetter = true; // Erste gültige Selektion
			} else if (testCircularity > bestCircularity + 0.05) {
				isBetter = true; // Deutlich kreisförmiger
			} else if (abs(testCircularity - bestCircularity) < 0.05 && testArea > bestArea) {
				isBetter = true; // Ähnliche Zirkularität, aber größer
			}
			
			if (isBetter) {
				bestTolerance = tolerance;
				bestArea = testArea;
				bestCircularity = testCircularity;
				bestROI = currentROI;
				print("    Tolerance=" + tolerance + ": ✓ BESTE (Area=" + d2s(testArea, 3) + "mm², Circ=" + d2s(testCircularity, 3) + ")");
			} else {
				print("    Tolerance=" + tolerance + ": ✓ gültig, aber nicht besser");
			}
		} else {
			print("    Tolerance=" + tolerance + ": ✗ " + reason + " (Area=" + d2s(testArea, 3) + "mm², Circ=" + d2s(testCircularity, 3) + ")");
		}
		
		// Entferne Selektion für nächsten Test
		run("Select None");
	}
	
	// Prüfe ob eine gültige Selektion gefunden wurde
	if (bestTolerance == -1) {
		print("\n  ❌ FEHLER: Keine gültige FAZ-Region gefunden!");
		print("  Getestete Toleranzen: " + TOLERANCE_START + " bis " + TOLERANCE_MAX);
		print("  Alle Selektionen waren zu klein, zu groß oder nicht kreisförmig genug.");
		showMessage("Warnung", "Keine gültige FAZ-Region gefunden!\n\n" +
		            "Kriterien:\n" +
		            "• Fläche: " + d2s(FAZ_MIN_AREA_MM2, 2) + " - " + d2s(FAZ_MAX_AREA_MM2, 2) + " mm²\n" +
		            "• Zirkularität: > " + d2s(FAZ_MIN_CIRCULARITY, 2) + "\n\n" +
		            "Möglicherweise ist die Bildqualität zu schlecht\n" +
		            "oder die FAZ ist nicht in der Bildmitte.");
		run("Clear Results");
		return;
	}
	
	// Verwende beste Selektion
	roiManager("Select", bestROI);
	print("\n  ✓ FAZ-Selektion gefunden mit Tolerance=" + bestTolerance);
	
	// Messe finale FAZ (nochmal für saubere Results Table)
	run("Clear Results");
	run("Set Measurements...", "area perimeter shape redirect=None decimal=4");
	run("Measure");
	
	// Extrahiere Ergebnisse
	fazArea = getResult("Area", nResults-1);
	fazPerimeter = getResult("Perim.", nResults-1);
	fazCircularity = getResult("Circ.", nResults-1);
	
	// Berechne Durchmesser (approximiert als Kreis)
	fazDiameter = 2 * sqrt(fazArea / PI);
	
	// Speichere in Tabelle
	rowIndex = Table.size("FAZ_Results");
	Table.set("Filename", rowIndex, baseFilename, "FAZ_Results");
	Table.set("FAZ_Area_mm2", rowIndex, fazArea, "FAZ_Results");
	Table.set("FAZ_Perimeter_mm", rowIndex, fazPerimeter, "FAZ_Results");
	Table.set("FAZ_Diameter_mm", rowIndex, fazDiameter, "FAZ_Results");
	Table.set("FAZ_Circularity", rowIndex, fazCircularity, "FAZ_Results");
	Table.update("FAZ_Results");
	
	// Zeige Ergebnis
	print("\n=== FAZ Messergebnisse ===");
	print("  Fläche: " + d2s(fazArea, 4) + " mm²");
	print("  Umfang: " + d2s(fazPerimeter, 3) + " mm");
	print("  Durchmesser: " + d2s(fazDiameter, 3) + " mm");
	print("  Zirkularität: " + d2s(fazCircularity, 3));
	
	// SCHRITT 4: Erstelle farbiges Overlay-Bild
	createFAZOverlay(baseFilename, outputDir);
	
	// Speichere ROI
	roiFilename = baseFilename + "_FAZ.roi";
	roiManager("Add");
	roiManager("Select", roiManager("count")-1);
	roiManager("Save", outputDir + "05_results" + File.separator + roiFilename);
	print("  ROI gespeichert: " + roiFilename);
	
	// Clear Results Table
	run("Clear Results");
	run("Select None");
}

// ========================================
// FAZ OVERLAY ERSTELLEN
// ========================================

function createFAZOverlay(baseFilename, outputDir) {
	// Speichere aktuelle FAZ-Selektion
	roiManager("Select", roiManager("count")-1);
	fazROI = roiManager("count")-1;
	
	// Hole FAZ Position auf dem gecroppten Bild
	getSelectionBounds(fazX_cropped, fazY_cropped, fazWidth, fazHeight);
	
	// Lade Original-Bild für vollständiges Overlay
	open(outputDir + "01_original" + File.separator + baseFilename + "_01_original.tif");
	originalImage = getTitle();
	
	// Konvertiere Original zu RGB für farbige Markierung
	run("RGB Color");
	
	// Berechne FAZ-Position im Original-Bild
	// Crop war: 275px von links, 0px von oben
	cropX = 275;
	cropY = 0;
	fazX_original = cropX + fazX_cropped;
	fazY_original = cropY + fazY_cropped;
	
	// Erstelle rechteckige ROI an korrekter Position im Original
	makeRectangle(fazX_original, fazY_original, fazWidth, fazHeight);
	
	// ODER: Übertrage die exakte FAZ-Form (Wand-Selektion)
	// Hole die originale ROI und verschiebe sie
	roiManager("Select", fazROI);
	run("Duplicate...", "title=temp");
	close("temp");
	
	// Verschiebe ROI zur Original-Position
	Roi.move(fazX_original, fazY_original);
	
	// Zeichne gelbe Markierung auf Original
	setForegroundColor(255, 255, 0);
	
	// Zeichne dicke Umrandung (3px statt 2px für bessere Sichtbarkeit)
	run("Enlarge...", "enlarge=3");
	run("Draw", "slice");
	
	// Restore ursprüngliche FAZ-Form und fülle halbtransparent
	Roi.move(fazX_original, fazY_original);
	setForegroundColor(255, 255, 100);  // Helleres Gelb für Füllung
	run("Fill", "slice");
	
	// Speichere das markierte Original-Bild
	saveAs("Tiff", outputDir + "04_FAZ_overlay" + File.separator + baseFilename + "_04_FAZ_overlay.tif");
	
	print("  ✓ FAZ-Overlay auf Originalbild gespeichert");
	
	// Cleanup
	close(baseFilename + "_04_FAZ_overlay.tif");
}

// ========================================
// HILFSFUNKTIONEN
// ========================================

function setImageScale(imageTitle) {
	selectWindow(imageTitle);
	width = getWidth();
	
	// Dialog für Scale-Einstellung
	Dialog.create("Set Scale");
	Dialog.addMessage("OCTA-Bildgröße einstellen:");
	Dialog.addNumber("Bekannte Distanz (mm):", OCTA_SIZE_MM);
	Dialog.addMessage("Bildbreite: " + width + " pixels");
	Dialog.show();
	
	knownDistance = Dialog.getNumber();
	
	// Setze Scale
	run("Set Scale...", "distance=" + width + " known=" + knownDistance + " unit=mm global");
	
	umPerPixel = (knownDistance * 1000) / width;
	print("Scale gesetzt: " + width + " pixels = " + knownDistance + " mm (" + d2s(umPerPixel, 2) + " µm/pixel)");
}

function getTimestamp() {
	getDateAndTime(year, month, dayOfWeek, dayOfMonth, hour, minute, second, msec);
	timestamp = "" + year;
	if (month < 9) timestamp = timestamp + "0";
	timestamp = timestamp + (month + 1);
	if (dayOfMonth < 10) timestamp = timestamp + "0";
	timestamp = timestamp + dayOfMonth + "_";
	if (hour < 10) timestamp = timestamp + "0";
	timestamp = timestamp + hour;
	if (minute < 10) timestamp = timestamp + "0";
	timestamp = timestamp + minute;
	if (second < 10) timestamp = timestamp + "0";
	timestamp = timestamp + second;
	
	return timestamp;
}

// ========================================
// PROGRAMMSTART
// ========================================

main();
