// TRIALMASTER QUICK ANALYSIS
// Schnelle Einzelbild-Analyse mit allen Standardwerten
// Für schnelle Tests und Einzelanalysen

requires("1.47g");

// ========================================
// KONFIGURATION
// ========================================

OCTA_SIZE_MM = 2.9;
PHANSALKAR_RADIUS = 6;

// ========================================
// HAUPTPROGRAMM
// ========================================

// Prüfe ob ein Bild geöffnet ist
if (nImages == 0) {
	showMessage("Fehler", "Bitte öffnen Sie zuerst ein OCTA-Bild.");
	exit();
}

originalImage = getTitle();
baseFilename = File.getNameWithoutExtension(originalImage);
directory = getDirectory("image");

// Dialog: Welche Analysen durchführen?
Dialog.create("Trialmaster Quick Analysis");
Dialog.addMessage("Wählen Sie die Analysen für: " + baseFilename);
Dialog.addCheckbox("Perfusionsdichte (PD)", true);
Dialog.addCheckbox("Vessel Density (VD)", true);
Dialog.addCheckbox("Choriocapillaris Flow Deficit (CC FD)", true);
Dialog.addMessage(" ");
Dialog.addNumber("OCTA Bildgröße (mm):", OCTA_SIZE_MM);
Dialog.show();

doPD = Dialog.getCheckbox();
doVD = Dialog.getCheckbox();
doCCFD = Dialog.getCheckbox();
octaSize = Dialog.getNumber();

// Erstelle Ausgabeordner
File.makeDirectory(directory + "01_original" + File.separator);
File.makeDirectory(directory + "02_cropped" + File.separator);
File.makeDirectory(directory + "03_8bit" + File.separator);
File.makeDirectory(directory + "04_binary_images" + File.separator);

// SCHRITT 1: Speichere Original
selectWindow(originalImage);
saveAs("Tiff", directory + "01_original" + File.separator + baseFilename + "_01_original.tif");
originalImage = getTitle();

// AUTOMATISCHES CROPPING
// Schritt 1: 275px von links und rechts entfernen
// Schritt 2: 110px von unten entfernen
selectWindow(originalImage);
widthOrig = getWidth();
heightOrig = getHeight();

// Berechne Crop-Parameter
cropX = 275; // Von links
cropY = 0; // Von oben (kein Crop oben)
cropWidth = widthOrig - 550; // 275px links + 275px rechts entfernen
cropHeight = heightOrig - 110; // 110px von unten entfernen

makeRectangle(cropX, cropY, cropWidth, cropHeight);
run("Crop");
run("Select None");

// SCHRITT 2: Speichere gecroptes Bild
saveAs("Tiff", directory + "02_cropped" + File.separator + baseFilename + "_02_cropped.tif");
originalImage = getTitle();

// Set Scale
width = getWidth(); // Neue Breite nach Crop (sollte 855 sein)
height = getHeight(); // Neue Höhe nach Crop (sollte 855 sein)
run("Set Scale...", "distance=" + width + " known=" + octaSize + " unit=mm global");
umPerPixel = (octaSize * 1000) / width;
print("\n=== Trialmaster Quick Analysis ===");
print("Bild: " + baseFilename);
print("Original: " + widthOrig + "px × " + heightOrig + "px");
print("Cropped: " + width + "px × " + height + "px (275px von links+rechts, 110px von unten entfernt)");
print("Scale: " + width + " pixels = " + octaSize + " mm (" + d2s(umPerPixel, 2) + " µm/pixel)");
print("");

// Konvertiere zu 8-bit
if (bitDepth() != 8) {
	run("8-bit");
}

// SCHRITT 3: Speichere 8-bit Version
saveAs("Tiff", directory + "03_8bit" + File.separator + baseFilename + "_03_8bit.tif");
originalImage = getTitle();

// Erstelle Ergebnis-Tabelle
Table.create("Quick_Analysis_Results");
Table.set("Filename", 0, baseFilename);
Table.set("Image_Width_px", 0, width);
Table.set("Image_Size_mm", 0, octaSize);
Table.set("um_per_pixel", 0, umPerPixel);

// ========================================
// ANALYSEN
// ========================================

// --- PERFUSIONSDICHTE ---
if (doPD) {
	print("Berechne Perfusionsdichte (PD)...");
	selectWindow(originalImage);
	run("Duplicate...", "title=PD_temp");
	
	setAutoThreshold("Otsu dark");
	setOption("BlackBackground", true);
	run("Convert to Mask");
	
	run("Select All");
	run("Set Measurements...", "area area_fraction redirect=None decimal=4");
	run("Measure");
	
	pdPercent = getResult("%Area", nResults-1);
	pdArea = getResult("Area", nResults-1);
	
	Table.set("PD_Percent", 0, pdPercent, "Quick_Analysis_Results");
	Table.set("PD_Fraction", 0, pdPercent/100, "Quick_Analysis_Results");
	Table.set("Total_Area_mm2", 0, pdArea, "Quick_Analysis_Results");
	
	print("  Perfusionsdichte: " + d2s(pdPercent, 2) + "%");
	print("  Gesamtfläche: " + d2s(pdArea, 4) + " mm²");
	
	saveAs("Tiff", directory + "04_binary_images" + File.separator + baseFilename + "_04_PD_binary.tif");
	close();
	run("Clear Results");
}

// --- VESSEL DENSITY ---
if (doVD) {
	print("\nBerechne Vessel Density (VD)...");
	selectWindow(originalImage);
	run("Duplicate...", "title=VD_temp");
	
	setAutoThreshold("Otsu dark");
	setOption("BlackBackground", true);
	run("Convert to Mask");
	run("Skeletonize");
	
	run("Select All");
	run("Set Measurements...", "area area_fraction redirect=None decimal=4");
	run("Measure");
	
	vdPercent = getResult("%Area", nResults-1);
	vdArea = getResult("Area", nResults-1);
	
	Table.set("VD_Percent", 0, vdPercent, "Quick_Analysis_Results");
	Table.set("VD_Fraction", 0, vdPercent/100, "Quick_Analysis_Results");
	
	print("  Vessel Density: " + d2s(vdPercent, 2) + "%");
	
	saveAs("Tiff", directory + "04_binary_images" + File.separator + baseFilename + "_04_VD_skeleton.tif");
	close();
	run("Clear Results");
}

// --- CHORIOCAPILLARIS FLOW DEFICIT ---
if (doCCFD) {
	print("\nBerechne Choriocapillaris Flow Deficit (CC FD)...");
	selectWindow(originalImage);
	run("Duplicate...", "title=CCFD_temp");
	
	run("Auto Local Threshold", "method=Phansalkar radius=" + PHANSALKAR_RADIUS + " parameter_1=0 parameter_2=0 white");
	run("Invert");
	
	run("Select All");
	run("Set Measurements...", "area area_fraction redirect=None decimal=4");
	run("Measure");
	
	fdPercent = getResult("%Area", nResults-1);
	fdTotalArea = getResult("Area", nResults-1);
	
	run("Clear Results");
	
	// Particle Analysis
	run("Set Measurements...", "area mean redirect=None decimal=4");
	run("Analyze Particles...", "size=0-Infinity show=Nothing display clear");
	
	fdCount = nResults;
	fdAvgSize = 0;
	fdArea = 0;
	
	if (fdCount > 0) {
		for (j = 0; j < fdCount; j++) {
			fdArea += getResult("Area", j);
		}
		fdAvgSize = fdArea / fdCount;
	}
	
	Table.set("CC_FD_Percent", 0, fdPercent, "Quick_Analysis_Results");
	Table.set("CC_FD_Fraction", 0, fdPercent/100, "Quick_Analysis_Results");
	Table.set("CC_FD_Count", 0, fdCount, "Quick_Analysis_Results");
	Table.set("CC_FD_Total_Area_mm2", 0, fdArea, "Quick_Analysis_Results");
	Table.set("CC_FD_Avg_Size_mm2", 0, fdAvgSize, "Quick_Analysis_Results");
	
	print("  Flow Deficit Density: " + d2s(fdPercent, 2) + "%");
	print("  FD Count: " + fdCount);
	print("  FD Avg Size: " + d2s(fdAvgSize, 6) + " mm²");
	
	saveAs("Tiff", directory + "04_binary_images" + File.separator + baseFilename + "_04_CC_FD_binary.tif");
	close();
	run("Clear Results");
}

// ========================================
// ERGEBNISSE ANZEIGEN & SPEICHERN
// ========================================

Table.update("Quick_Analysis_Results");

// Speichere CSV
getDateAndTime(year, month, dayOfWeek, dayOfMonth, hour, minute, second, msec);
timestamp = "" + year;
if (month < 9) timestamp = timestamp + "0";
timestamp = timestamp + (month + 1);
if (dayOfMonth < 10) timestamp = timestamp + "0";
timestamp = timestamp + dayOfMonth + "_";
if (hour < 10) timestamp = timestamp + "0";
timestamp = timestamp + hour;
if (minute < 10) timestamp = timestamp + "0";
timestamp = timestamp + minute;
if (second < 10) timestamp = timestamp + "0";
timestamp = timestamp + second;

csvFilename = baseFilename + "_QuickAnalysis_" + timestamp + ".csv";
Table.save(directory + csvFilename, "Quick_Analysis_Results");

print("\n=== Analyse abgeschlossen ===");
print("Ergebnisse gespeichert: " + csvFilename);
print("Binäre Bilder gespeichert in: " + directory);

// Zusammenfassung anzeigen
summary = "=== TRIALMASTER QUICK ANALYSIS ===\n\n";
summary += "Datei: " + baseFilename + "\n";
summary += "Bildgröße: " + octaSize + " mm (" + width + " px)\n\n";

if (doPD) {
	summary += "PERFUSIONSDICHTE (PD):\n";
	summary += "  " + d2s(Table.get("PD_Percent", 0), 2) + "%\n";
	summary += "  (Referenz: 21-27%)\n\n";
}

if (doVD) {
	summary += "VESSEL DENSITY (VD):\n";
	summary += "  " + d2s(Table.get("VD_Percent", 0), 2) + "%\n";
	summary += "  (Referenz: ~9%)\n\n";
}

if (doCCFD) {
	summary += "CHORIOCAPILLARIS FLOW DEFICIT:\n";
	summary += "  Density: " + d2s(Table.get("CC_FD_Percent", 0), 2) + "%\n";
	summary += "  Count: " + Table.get("CC_FD_Count", 0) + "\n";
	summary += "  Avg Size: " + d2s(Table.get("CC_FD_Avg_Size_mm2", 0), 6) + " mm²\n";
	summary += "  (Referenz Density: 21.4±5.7%)\n\n";
}

summary += "\nErgebnisse in: " + directory + "\n";
summary += "CSV: " + csvFilename;

showMessage("Analyse Abgeschlossen", summary);

selectWindow(originalImage);
