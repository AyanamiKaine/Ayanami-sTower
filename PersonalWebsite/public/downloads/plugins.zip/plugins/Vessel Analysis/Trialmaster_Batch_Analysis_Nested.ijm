// TRIALMASTER BATCH ANALYSIS (NESTED FOLDERS)
// Automatisierte Analyse für verschachtelte OCTA-Ordnerstruktur
// Verarbeitet: CCFD_OD, CCFD_OS, DCP_OD, DCP_OS, ICP_OD, ICP_OS, SCP_OD, SCP_OS
// Analysen: Perfusionsdichte (PD), Vessel Density (VD), Choriocapillaris Flow Deficit (CC FD)

requires("1.47g");

// ========================================
// KONFIGURATION
// ========================================

// Verzeichnisse
inputDir = "";
outputDir = "";

// OCTA Bildparameter
OCTA_SIZE_MM = 2.9; // Standard OCTA Bildgröße in mm

// Analyse-Optionen (abhängig von Ordnername)
analysisPerFolder = newArray(
	"CCFD_OD", "CCFD_OS",  // CC Flow Deficit
	"DCP_OD", "DCP_OS",    // Deep Capillary Plexus
	"ICP_OD", "ICP_OS",    // Intermediate Capillary Plexus
	"SCP_OD", "SCP_OS"     // Superficial Capillary Plexus
);

// Phansalkar Parameter für CC FD (aus Wang et al.)
PHANSALKAR_RADIUS = 6; // pixels (17.4 µm bei 2.9 µm/pixel)

// ADAPTIVE FAZ TOLERANZ-KONFIGURATION
TOLERANCE_START = 2;        // Starttoleranz (konservativ)
TOLERANCE_MAX = 10;         // Maximale Toleranz
TOLERANCE_STEP = 2;         // Schrittweise beim Erhöhen
MAGIC_WAND_MODE = "4-connected"; // 4-connected oder 8-connected

// FAZ QUALITÄTSKRITERIEN
FAZ_MIN_AREA_MM2 = 0.10;    // Minimum FAZ-Fläche (zu klein = Fehler)
FAZ_MAX_AREA_MM2 = 0.80;    // Maximum FAZ-Fläche (zu groß = Fehler)
FAZ_MIN_CIRCULARITY = 0.60; // Minimum Zirkularität (zu irregulär = Fehler)
MAGIC_WAND_MODE = "4-connected"; // 4-connected oder 8-connected

// ========================================
// HAUPTPROGRAMM
// ========================================

function main() {
	// Verzeichnisauswahl
	inputDir = getDirectory("Wählen Sie den HAUPTORDNER (enthält CCFD_OD, DCP_OD, etc.)");
	outputDir = getDirectory("Wählen Sie den Ausgabeordner für Ergebnisse");
	
	// Liste der Unterordner
	folderList = getFileList(inputDir);
	subfolders = filterDirectories(folderList);
	
	if (subfolders.length == 0) {
		showMessage("Fehler", "Keine Unterordner gefunden.\n\nErwartet: CCFD_OD, CCFD_OS, DCP_OD, DCP_OS, etc.");
		return;
	}
	
	print("\n=== TRIALMASTER BATCH ANALYSIS (NESTED) ===");
	print("Hauptordner: " + inputDir);
	print("Gefundene Unterordner: " + subfolders.length);
	for (i = 0; i < subfolders.length; i++) {
		print("  - " + subfolders[i]);
	}
	
	// Erstelle Ergebnis-Tabellen
	Table.create("All_Results");
	
	// Verarbeite jeden Unterordner
	totalImages = 0;
	for (i = 0; i < subfolders.length; i++) {
		folderName = subfolders[i];
		
		// Entferne Trailing Slash
		if (endsWith(folderName, File.separator)) {
			folderName = substring(folderName, 0, lengthOf(folderName) - 1);
		}
		
		print("\n--- Verarbeite Ordner: " + folderName + " ---");
		
		// Bestimme Analyse-Typ basierend auf Ordnername
		analysisType = determineAnalysisType(folderName);
		eyeSide = determineEyeSide(folderName);
		
		print("  Analyse-Typ: " + analysisType);
		print("  Auge: " + eyeSide);
		
		// Verarbeite alle Bilder in diesem Unterordner
		count = processFolderImages(inputDir + subfolders[i], folderName, analysisType, eyeSide);
		totalImages += count;
		
		print("  ✓ " + count + " Bilder verarbeitet");
	}
	
	// Ergebnisse speichern
	saveResults();
	
	// Abschlussmeldung
	print("\n=== ANALYSE ABGESCHLOSSEN ===");
	print("Unterordner: " + subfolders.length);
	print("Bilder gesamt: " + totalImages);
	print("Output: " + outputDir);
	
	showMessage("Fertig!", 
	            "Batch-Analyse abgeschlossen!\n\n" +
	            "Unterordner: " + subfolders.length + "\n" +
	            "Bilder gesamt: " + totalImages + "\n\n" +
	            "Ergebnisse gespeichert in:\n" + outputDir);
}

// ========================================
// ORDNER-VERARBEITUNG
// ========================================

function processFolderImages(folderPath, folderName, analysisType, eyeSide) {
	// Erstelle Output-Unterordner für diesen Ordner
	folderOutputDir = outputDir + folderName + File.separator;
	File.makeDirectory(folderOutputDir);
	File.makeDirectory(folderOutputDir + "01_original" + File.separator);
	File.makeDirectory(folderOutputDir + "02_cropped" + File.separator);
	File.makeDirectory(folderOutputDir + "03_8bit" + File.separator);
	File.makeDirectory(folderOutputDir + "04_binary_images" + File.separator);
	File.makeDirectory(folderOutputDir + "04_FAZ_overlay" + File.separator);
	File.makeDirectory(folderOutputDir + "05_results" + File.separator);
	
	// Hole Bilddateien aus diesem Ordner
	fileList = getFileList(folderPath);
	imageFiles = filterImageFiles(fileList);
	
	if (imageFiles.length == 0) {
		print("  WARNUNG: Keine Bilddateien in " + folderName);
		return 0;
	}
	
	// Batch-Modus für Geschwindigkeit
	setBatchMode(true);
	
	// Verarbeite jedes Bild
	for (i = 0; i < imageFiles.length; i++) {
		showProgress(i, imageFiles.length);
		
		filename = imageFiles[i];
		print("    (" + (i+1) + "/" + imageFiles.length + ") " + filename);
		
		processImage(folderPath, filename, folderOutputDir, folderName, analysisType, eyeSide, i);
		
		// Speicher freigeben
		run("Collect Garbage");
	}
	
	setBatchMode(false);
	
	return imageFiles.length;
}

// ========================================
// BILDVERARBEITUNG
// ========================================

function processImage(folderPath, filename, folderOutputDir, folderName, analysisType, eyeSide, index) {
	// Öffne Bild
	open(folderPath + filename);
	originalImage = getTitle();
	baseFilename = File.getNameWithoutExtension(filename);
	
	// SCHRITT 1: Speichere Original
	saveAs("Tiff", folderOutputDir + "01_original" + File.separator + baseFilename + "_01_original.tif");
	originalImage = getTitle();
	
	// AUTOMATISCHES CROPPING
	// 275px von links und rechts, 110px von unten
	width = getWidth();
	height = getHeight();
	
	cropX = 275;
	cropY = 0;
	cropWidth = width - 550;
	cropHeight = height - 110;
	
	makeRectangle(cropX, cropY, cropWidth, cropHeight);
	run("Crop");
	run("Select None");
	
	// SCHRITT 2: Speichere gecroptes Bild
	saveAs("Tiff", folderOutputDir + "02_cropped" + File.separator + baseFilename + "_02_cropped.tif");
	originalImage = getTitle();
	
	// Set Scale
	finalWidth = getWidth();
	run("Set Scale...", "distance=" + finalWidth + " known=" + OCTA_SIZE_MM + " unit=mm global");
	
	// Konvertiere zu 8-bit
	if (bitDepth() != 8) {
		run("8-bit");
	}
	
	// SCHRITT 3: Speichere 8-bit Version
	saveAs("Tiff", folderOutputDir + "03_8bit" + File.separator + baseFilename + "_03_8bit.tif");
	originalImage = getTitle();
	
	// Führe passende Analyse durch
	if (analysisType == "CC_FD") {
		// Nur CC Flow Deficit
		analyzeChoriocapillarisFD(baseFilename, folderName, eyeSide, folderOutputDir, index);
	} else if (analysisType == "DCP" || analysisType == "ICP" || analysisType == "SCP") {
		// Für Capillary Plexus: FAZ ZUERST (auf unbearbeitetem 8-bit), dann PD + VD
		// WICHTIG: FAZ muss vor PD/VD durchgeführt werden, da diese das Bild verändern
		analyzeFAZAutomatic(baseFilename, folderName, eyeSide, analysisType, folderOutputDir, index);
		analyzePerfusionDensity(baseFilename, folderName, eyeSide, analysisType, folderOutputDir, index);
		analyzeVesselDensity(baseFilename, folderName, eyeSide, analysisType, folderOutputDir, index);
	}
	
	// Schließe alle Bilder
	close("*");
}

// ========================================
// PERFUSIONSDICHTE (PD)
// ========================================

function analyzePerfusionDensity(baseFilename, folderName, eyeSide, layer, folderOutputDir, index) {
	// Dupliziere aktuelles Bild
	run("Duplicate...", "title=PD_working");
	
	// Otsu Threshold
	setAutoThreshold("Otsu dark");
	setOption("BlackBackground", true);
	run("Convert to Mask");
	
	// Speichere binäres Bild (SCHRITT 4)
	saveAs("Tiff", folderOutputDir + "04_binary_images" + File.separator + baseFilename + "_04_PD_binary.tif");
	
	// Messe gesamte Bildfläche
	run("Select All");
	run("Set Measurements...", "area area_fraction redirect=None decimal=4");
	run("Measure");
	
	// Extrahiere Ergebnisse
	totalArea = getResult("Area", nResults-1);
	areaFraction = getResult("%Area", nResults-1);
	
	// Berechne Perfusionsdichte
	perfusionDensity = areaFraction; // In Prozent
	
	// Speichere in Tabelle
	rowIndex = Table.size("All_Results");
	Table.set("Folder", rowIndex, folderName, "All_Results");
	Table.set("Eye", rowIndex, eyeSide, "All_Results");
	Table.set("Layer", rowIndex, layer, "All_Results");
	Table.set("Filename", rowIndex, baseFilename, "All_Results");
	Table.set("Analysis", rowIndex, "PD", "All_Results");
	Table.set("Total_Area_mm2", rowIndex, totalArea, "All_Results");
	Table.set("Perfusion_Density_%", rowIndex, perfusionDensity, "All_Results");
	Table.update("All_Results");
	
	// Clear Results
	run("Clear Results");
	
	// Schließe Working Image
	close("PD_working");
}

// ========================================
// VESSEL DENSITY (VD)
// ========================================

function analyzeVesselDensity(baseFilename, folderName, eyeSide, layer, folderOutputDir, index) {
	// Dupliziere aktuelles Bild
	run("Duplicate...", "title=VD_working");
	
	// Otsu Threshold
	setAutoThreshold("Otsu dark");
	setOption("BlackBackground", true);
	run("Convert to Mask");
	
	// Skeletonisierung
	run("Skeletonize");
	
	// Speichere Skeleton (SCHRITT 4)
	saveAs("Tiff", folderOutputDir + "04_binary_images" + File.separator + baseFilename + "_04_VD_skeleton.tif");
	
	// Messe Skeleton
	run("Select All");
	run("Set Measurements...", "area area_fraction redirect=None decimal=4");
	run("Measure");
	
	// Extrahiere Ergebnisse
	totalArea = getResult("Area", nResults-1);
	skeletonFraction = getResult("%Area", nResults-1);
	
	// Berechne Vessel Density
	vesselDensity = skeletonFraction; // In Prozent
	
	// Speichere in Tabelle
	rowIndex = Table.size("All_Results");
	Table.set("Folder", rowIndex, folderName, "All_Results");
	Table.set("Eye", rowIndex, eyeSide, "All_Results");
	Table.set("Layer", rowIndex, layer, "All_Results");
	Table.set("Filename", rowIndex, baseFilename, "All_Results");
	Table.set("Analysis", rowIndex, "VD", "All_Results");
	Table.set("Total_Area_mm2", rowIndex, totalArea, "All_Results");
	Table.set("Vessel_Density_%", rowIndex, vesselDensity, "All_Results");
	Table.update("All_Results");
	
	// Clear Results
	run("Clear Results");
	
	// Schließe Working Image
	close("VD_working");
}

// ========================================
// CHORIOCAPILLARIS FLOW DEFICIT (CC FD)
// ========================================

function analyzeChoriocapillarisFD(baseFilename, folderName, eyeSide, folderOutputDir, index) {
	// Dupliziere aktuelles Bild
	run("Duplicate...", "title=CC_FD_working");
	
	// Phansalkar Local Threshold (aus Wang et al. 2023)
	run("Auto Local Threshold", "method=Phansalkar radius=" + PHANSALKAR_RADIUS + " parameter_1=0 parameter_2=0 white");
	
	// Speichere binäres Bild (SCHRITT 4)
	saveAs("Tiff", folderOutputDir + "04_binary_images" + File.separator + baseFilename + "_04_CC_FD_binary.tif");
	
	// Messe Flow Deficit
	run("Select All");
	run("Set Measurements...", "area area_fraction redirect=None decimal=4");
	run("Measure");
	
	// Extrahiere Ergebnisse
	totalArea = getResult("Area", nResults-1);
	deficitFraction = getResult("%Area", nResults-1);
	
	// Flow Deficit Percentage
	flowDeficit = deficitFraction;
	
	// Speichere in Tabelle
	rowIndex = Table.size("All_Results");
	Table.set("Folder", rowIndex, folderName, "All_Results");
	Table.set("Eye", rowIndex, eyeSide, "All_Results");
	Table.set("Layer", rowIndex, "CC", "All_Results");
	Table.set("Filename", rowIndex, baseFilename, "All_Results");
	Table.set("Analysis", rowIndex, "CC_FD", "All_Results");
	Table.set("Total_Area_mm2", rowIndex, totalArea, "All_Results");
	Table.set("Flow_Deficit_%", rowIndex, flowDeficit, "All_Results");
	Table.update("All_Results");
	
	// Clear Results
	run("Clear Results");
	
	// Schließe Working Image
	close("CC_FD_working");
}

// ========================================
// FAZ MESSUNG (AUTOMATISCH)
// ========================================

function analyzeFAZAutomatic(baseFilename, folderName, eyeSide, layer, folderOutputDir, index) {
	// Aktives Bild verwenden (bereits 8-bit mit Scale)
	width = getWidth();
	height = getHeight();
	
	// Bildmitte berechnen
	centerX = round(width / 2);
	centerY = round(height / 2);
	
	// ADAPTIVE TOLERANZ: Teste verschiedene Werte
	bestTolerance = -1;
	bestArea = 0;
	bestCircularity = 0;
	bestROI = -1;
	
	// Teste verschiedene Toleranzen in Bildmitte
	for (tolerance = TOLERANCE_START; tolerance <= TOLERANCE_MAX; tolerance += TOLERANCE_STEP) {
		// Versuche Magic Wand mit aktueller Toleranz
		doWand(centerX, centerY, tolerance, MAGIC_WAND_MODE);
		
		// Prüfe ob Selektion existiert
		if (selectionType() == -1) {
			continue;
		}
		
		// Messe aktuelle Selektion
		run("Set Measurements...", "area perimeter shape redirect=None decimal=4");
		run("Measure");
		
		testArea = getResult("Area", nResults-1);
		testPerimeter = getResult("Perim.", nResults-1);
		testCircularity = getResult("Circ.", nResults-1);
		
		// Prüfe Qualitätskriterien
		isValid = true;
		
		if (testArea < FAZ_MIN_AREA_MM2) {
			isValid = false;
		} else if (testArea > FAZ_MAX_AREA_MM2) {
			isValid = false;
		} else if (testCircularity < FAZ_MIN_CIRCULARITY) {
			isValid = false;
		}
		
		// Speichere ROI falls gültig
		if (isValid) {
			roiManager("Add");
			currentROI = roiManager("count") - 1;
			
			// Ist diese Selektion besser?
			isBetter = false;
			if (bestTolerance == -1) {
				isBetter = true;
			} else if (testCircularity > bestCircularity + 0.05) {
				isBetter = true;
			} else if (abs(testCircularity - bestCircularity) < 0.05 && testArea > bestArea) {
				isBetter = true;
			}
			
			if (isBetter) {
				bestTolerance = tolerance;
				bestArea = testArea;
				bestCircularity = testCircularity;
				bestROI = currentROI;
			}
		}
		
		// Entferne Selektion für nächsten Test
		run("Select None");
	}
	
	// Prüfe ob eine gültige Selektion gefunden wurde
	if (bestTolerance == -1) {
		// Keine FAZ gefunden - Warnung in Tabelle
		rowIndex = Table.size("All_Results");
		Table.set("Folder", rowIndex, folderName, "All_Results");
		Table.set("Eye", rowIndex, eyeSide, "All_Results");
		Table.set("Layer", rowIndex, layer, "All_Results");
		Table.set("Filename", rowIndex, baseFilename, "All_Results");
		Table.set("Analysis", rowIndex, "FAZ", "All_Results");
		Table.set("Total_Area_mm2", rowIndex, NaN, "All_Results");
		Table.set("FAZ_Area_mm2", rowIndex, NaN, "All_Results");
		Table.set("FAZ_Perimeter_mm", rowIndex, NaN, "All_Results");
		Table.set("FAZ_Diameter_mm", rowIndex, NaN, "All_Results");
		Table.set("FAZ_Circularity", rowIndex, NaN, "All_Results");
		Table.set("Note", rowIndex, "No valid FAZ found", "All_Results");
		Table.update("All_Results");
		run("Clear Results");
		return;
	}
	
	// Verwende beste Selektion
	roiManager("Select", bestROI);
	
	// Messe finale FAZ
	run("Clear Results");
	run("Set Measurements...", "area perimeter shape redirect=None decimal=4");
	run("Measure");
	
	// Extrahiere Ergebnisse
	totalArea = getResult("Area", nResults-1);
	fazArea = totalArea; // Bei FAZ ist die Selection die FAZ
	fazPerimeter = getResult("Perim.", nResults-1);
	fazCircularity = getResult("Circ.", nResults-1);
	
	// Berechne Durchmesser (approximiert als Kreis)
	fazDiameter = 2 * sqrt(fazArea / PI);
	
	// Speichere in Tabelle
	rowIndex = Table.size("All_Results");
	Table.set("Folder", rowIndex, folderName, "All_Results");
	Table.set("Eye", rowIndex, eyeSide, "All_Results");
	Table.set("Layer", rowIndex, layer, "All_Results");
	Table.set("Filename", rowIndex, baseFilename, "All_Results");
	Table.set("Analysis", rowIndex, "FAZ", "All_Results");
	Table.set("Total_Area_mm2", rowIndex, totalArea, "All_Results");
	Table.set("FAZ_Area_mm2", rowIndex, fazArea, "All_Results");
	Table.set("FAZ_Perimeter_mm", rowIndex, fazPerimeter, "All_Results");
	Table.set("FAZ_Diameter_mm", rowIndex, fazDiameter, "All_Results");
	Table.set("FAZ_Circularity", rowIndex, fazCircularity, "All_Results");
	Table.update("All_Results");
	
	// Erstelle farbiges Overlay-Bild
	createFAZOverlay(baseFilename, folderOutputDir);
	
	// Clear Results
	run("Clear Results");
	run("Select None");
}

// ========================================
// FAZ OVERLAY ERSTELLEN
// ========================================

function createFAZOverlay(baseFilename, folderOutputDir) {
	// Speichere aktuelle FAZ-Selektion im ROI Manager
	roiManager("Add");
	currentROI = roiManager("count") - 1;
	
	// Hole FAZ Position auf dem gecroppten Bild
	roiManager("Select", currentROI);
	getSelectionBounds(fazX_cropped, fazY_cropped, fazWidth, fazHeight);
	
	// Lade Original-Bild für vollständiges Overlay
	open(folderOutputDir + "01_original" + File.separator + baseFilename + "_01_original.tif");
	originalImage = getTitle();
	
	// Konvertiere Original zu RGB für farbige Markierung
	run("RGB Color");
	
	// Berechne FAZ-Position im Original-Bild
	// Crop war: 275px von links, 0px von oben
	cropX = 275;
	cropY = 0;
	fazX_original = cropX + fazX_cropped;
	fazY_original = cropY + fazY_cropped;
	
	// Übertrage die exakte FAZ-Form zur Original-Position
	roiManager("Select", currentROI);
	Roi.move(fazX_original, fazY_original);
	
	// Zeichne gelbe Markierung auf Original
	setForegroundColor(255, 255, 0);
	
	// Zeichne dicke Umrandung (3px für bessere Sichtbarkeit)
	run("Enlarge...", "enlarge=3");
	run("Draw", "slice");
	
	// Restore ursprüngliche FAZ-Form und fülle halbtransparent
	roiManager("Select", currentROI);
	Roi.move(fazX_original, fazY_original);
	setForegroundColor(255, 255, 100);  // Helleres Gelb für Füllung
	run("Fill", "slice");
	
	// Speichere das markierte Original-Bild
	saveAs("Tiff", folderOutputDir + "04_FAZ_overlay" + File.separator + baseFilename + "_04_FAZ_overlay.tif");
	
	// Cleanup
	close(baseFilename + "_04_FAZ_overlay.tif");
	
	// Speichere auch ROI (an Original-Position)
	roiManager("Select", currentROI);
	Roi.move(fazX_original, fazY_original);
	roiManager("Save", folderOutputDir + "05_results" + File.separator + baseFilename + "_FAZ.roi");
	
	// Entferne ROI aus Manager
	roiManager("Select", currentROI);
	roiManager("Delete");
}

// ========================================
// HILFSFUNKTIONEN
// ========================================


function determineAnalysisType(folderName) {
	// Entferne Trailing Slash falls vorhanden
	if (endsWith(folderName, File.separator)) {
		folderName = substring(folderName, 0, lengthOf(folderName) - 1);
	}
	
	// Prüfe Ordnername
	if (startsWith(folderName, "CCFD")) {
		return "CC_FD";
	} else if (startsWith(folderName, "DCP")) {
		return "DCP";
	} else if (startsWith(folderName, "ICP")) {
		return "ICP";
	} else if (startsWith(folderName, "SCP")) {
		return "SCP";
	} else {
		return "Unknown";
	}
}

function determineEyeSide(folderName) {
	// Entferne Trailing Slash
	if (endsWith(folderName, File.separator)) {
		folderName = substring(folderName, 0, lengthOf(folderName) - 1);
	}
	
	// Prüfe auf _OD oder _OS
	if (endsWith(folderName, "_OD") || endsWith(folderName, "OD")) {
		return "OD"; // Right Eye (Oculus Dexter)
	} else if (endsWith(folderName, "_OS") || endsWith(folderName, "OS")) {
		return "OS"; // Left Eye (Oculus Sinister)
	} else {
		return "Unknown";
	}
}

function filterDirectories(list) {
	// Filtere nur Verzeichnisse
	dirs = newArray(0);
	for (i = 0; i < list.length; i++) {
		if (endsWith(list[i], File.separator)) {
			// Ist ein Verzeichnis
			dirs = Array.concat(dirs, list[i]);
		}
	}
	return dirs;
}

function filterImageFiles(list) {
	// Filtere Bilddateien (tif, tiff, jpg, png)
	images = newArray(0);
	for (i = 0; i < list.length; i++) {
		name = toLowerCase(list[i]);
		if (endsWith(name, ".tif") || endsWith(name, ".tiff") || 
		    endsWith(name, ".jpg") || endsWith(name, ".jpeg") || 
		    endsWith(name, ".png")) {
			images = Array.concat(images, list[i]);
		}
	}
	return images;
}

function saveResults() {
	timestamp = getTimestamp();
	
	// Speichere Combined Results
	if (isOpen("All_Results")) {
		Table.save(outputDir + "All_Results_" + timestamp + ".csv", "All_Results");
		print("\n✓ Ergebnisse gespeichert: All_Results_" + timestamp + ".csv");
	}
}

function getTimestamp() {
	getDateAndTime(year, month, dayOfWeek, dayOfMonth, hour, minute, second, msec);
	timestamp = "" + year;
	if (month < 9) timestamp = timestamp + "0";
	timestamp = timestamp + (month + 1);
	if (dayOfMonth < 10) timestamp = timestamp + "0";
	timestamp = timestamp + dayOfMonth + "_";
	if (hour < 10) timestamp = timestamp + "0";
	timestamp = timestamp + hour;
	if (minute < 10) timestamp = timestamp + "0";
	timestamp = timestamp + minute;
	if (second < 10) timestamp = timestamp + "0";
	timestamp = timestamp + second;
	
	return timestamp;
}

// ========================================
// PROGRAMMSTART
// ========================================

main();
